






<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google" value="notranslate">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <link rel="stylesheet" href="/css/style.css">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
    <script src="https://unpkg.com/gijgo@1.9.13/js/messages/messages.es-es.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>


    @if (session('alert_error'))
    <script>
      $(document).ready(function()
      {
        $("#alert_error").modal("show");
    });
</script>
@include('sections.modal_alert_error')
@endif

@if (session('alert_success'))
    <script>
      $(document).ready(function()
      {
        $("#alert_success").modal("show");
    });
</script>
@include('sections.modal_alert_success')
@endif


<div class="portada">
    <div id="header" >
     <a href="#" >FELIPE II</a>
 </div>
 <div class="text">
  <h1>INSCRIBE TU RECIBO Y GANA</h1> 
  <h3>Participa y Gana con Felipe Segundo</h3>
  <div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" >

                {{--  <div class="card-header">{{ __('Register') }}</div>--}}
                @include('sections.preload')
                <div class="card-body">
                    <form class="form-horizontal" method="POST" action="{{ route('registerReceipt') }}" enctype="multipart/form-data" onsubmit="return preload()" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="form-group row {{ $errors->has('nacimiento') ? ' is-invalid' : '' }}">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Fecha de Nacimiento') }}</label>
                            <div class="col-md-8" >
                                <input id="datepicker" type="text" class="form-control" name="nacimiento" value="{{ old('nacimiento') }}" required autofocus readonly="true" />
                                @if ($errors->has('nacimiento'))
                                <span class="help-block" role="alert">
                                    <strong>{{ $errors->first('nacimiento') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <script>
                            $('#datepicker').datepicker({
                                uiLibrary: 'bootstrap4',
                                locale: 'es-es',
                                format: 'yyyy-dd-mm'
                            });
                        </script>
                        <div class="form-group row {{ $errors->has('nombres') ? ' is-invalid' : '' }}">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Nombres') }}</label>
                            <div class="col-md-8">
                                <input id="name" type="text" class="form-control" name="nombres" value="{{ old('nombres') }}" required autofocus>

                                @if ($errors->has('nombres'))
                                <span class="help-block" role="alert">
                                    <strong>{{ $errors->first('nombres') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row {{ $errors->has('apellidos') ? ' is-invalid' : '' }}">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Apellidos') }}</label>

                            <div class="col-md-8">
                                <input id="name" type="text" class="form-control" name="apellidos" value="{{ old('apellidos') }}" required autofocus>

                                @if ($errors->has('apellidos'))
                                <span class="help-block" role="alert">
                                    <strong>{{ $errors->first('apellidos') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row{{ $errors->has('supermercado') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Supermercado Econo') }}</label>
                            <div class="col-md-8">
                                <select   id="supermercado" type="text" name="supermercado"  class="form-control" required>
                                    <option value="{{ old('supermercado')== null? '' : old('supermercado')}}" >{{ old('supermercado')== null? "Donde Hizo la Compra ?" : old('supermercado')}}</option> 

                                    @for ($i = 0; $i < 15; $i++)
                                            {{-- expr --}}
                                            
                                    <option value="Supermercado {{ $i }}">Supermercado {{ $i }}</option>
                                    @endfor
                                    
                                </select>
                                @if ($errors->has('supermercado'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('supermercado') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row{{ $errors->has('recibo') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 col-form-label text-md-right">Numero de Recibo</label>
                            <div class="col-md-8">
                                <input id="recibo"  type="number" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="form-control" name="recibo" value="{{ old('recibo') }}" maxlength="50"min="1" required autofocus >

                                @if ($errors->has('recibo'))
                                <span class="help-block">
                                    <strong >{{ $errors->first('recibo') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">Seleccionar imagen del Recibo</label>
                            <div class="col-md-8" >
                             <label for="fper_user" class="subir" style="width: 50%;">
                                 <!-- <i class="fa fa-cloud-upload" aria-hidden="true" ></i>&nbsp;&nbsp;-->
                                 <div id="log" ></div>
                                 <img src="/images/rec.jpg" id="prev_profile_user_i" width="100%" class="img-fluid img-thumbnail"  />
                             </label>
                         </div>
                         <label for="name" class="col-md-4 col-form-label text-md-right"></label>
                         <div class="col-md-8"  >
                             <div class="fper-usu" style=" ">
                                <img src="/images/rec.jpg" id="prev_profile_user" width="100%" class="img-fluid img-thumbnail"  style="display: none;" />
                            </div>
                        </div>
                        <input name="fper" id="fper_user" onchange='validationProfileUser()' type="file" style='display: none;' required  />
                    </div>
                    <script type="text/javascript">
                        function validationProfileUser(){
                            var fileInput = document.getElementById('fper_user');
                            var filePath = fileInput.value;
                            var required_file = "";
                            var allowedExtensions = /(.jpg|.jpeg|.png|.gif|.JPG|.JPEG|.PNG|.GIF)$/i;
                            required_file = ".jpg  .png  .gif" ;
                            if(!allowedExtensions.exec(filePath)){
                               // alert('Solo puede subir los archivos requeridos : ' +required_file);
                               swal("Upps !", "Solo puede subir la imagen requerida : " +required_file, "info");
                               fileInput.value = '';
                               return false;
                           }else{
                            if (fileInput.files && fileInput.files[0]) {
                                var reader = new FileReader();
                                reader.onload = function(e) {

                                    var result=e.target.result;
                                    $('#prev_profile_user').show();
                                    $('#prev_profile_user_i').hide();
                                    $('#log').text('Seleccionar Otro Recibo ');
                                    $('#prev_profile_user').attr("src",result);
                                };
                                reader.readAsDataURL(fileInput.files[0]);
                            }
                        }
                    }
                </script>
                <div class="form-group row mb-0">
                    <div class="col-md-8 offset-md-4">
                        <button type="submit" class="btn btn-ttc btn-block" >
                            <i class="fa fa-registered" aria-hidden="true" style="color: white !important;"></i>&nbsp;&nbsp;{{ __('Registrar Recibo') }}
                        </button>
                    </div>
                </div>

                <div class="col-md-12 fat"  >
                    <hr class="hrt">
                    <a href="{{ route('login') }}" class="ad" onclick="preload()"><i class="fa fa-user" aria-hidden="true"></i>Login</a>
                    <a href="" target="_blank">
                       <i class="fa fa-facebook-f" aria-hidden="true"></i>
                   </a>
                   <a href="" target="_blank">
                       <i class="fa fa-twitter " aria-hidden="true"></i>
                   </a>
               </div>
           </form>
       </div>
   </div>

</div>





</body>

</html>



{{--   <!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/css/style.css">

</head>
<body class="backg">
    <div class="flex-center position-ref full-height">
        @if (Route::has('login'))
        <div class="top-right links">
            @auth
            <a href="{{ url('/home') }}">Home</a>
            @else
            <a href="{{ route('login') }}">Login</a>
            <a href="{{ route('register') }}">Register</a>
            @endauth
        </div>
        @endif

        <div class="content">
            <div class="title m-b-md">
                Laravel
            </div>

            <div class="links">
                <a href="https://laravel.com/docs">Documentation</a>
                <a href="https://laracasts.com">Laracasts</a>
                <a href="https://laravel-news.com">News</a>
                <a href="https://forge.laravel.com">Forge</a>
                <a href="https://github.com/laravel/laravel">GitHub</a>
            </div>
        </div>
    </div>
</body>
</html>

--}}
