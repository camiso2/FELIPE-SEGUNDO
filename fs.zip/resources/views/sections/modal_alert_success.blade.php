<!-- Modal -->

<div class="modal fade" id="alert_success" role="dialog" data-backdrop="true">
	<div class="modal-dialog modal-xs" >
		<!-- Modal content-->
		<div class="modal-content" >
			<div class="modal-body" style="text-align: center;">
				<br>
				<div style="">
					<img src="/images/logo.png" alt="" class=" img-responsive img-thumbnail" width="55%"><hr style="background-color: white">
				</div>

				<br>
				<h2 style="font-weight: 800; font-size: 25px;color:#B50338 ">{{ session('alert_success') }}</h2>	
				<br>
				
				<button type="button" class="btn btn-ttc btn-style" style="background-color: #B50338" data-dismiss="modal">QUIERO REGISTRAR MAS RECIBOS DE COMPRA</button><br>
			</div>
		</div>
	</div>
</div>