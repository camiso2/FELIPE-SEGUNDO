<footer >
    <div class="">

        <p class="pull-center">© 2020 <a href="#" target="_blank"> Jaiver Ocampo</a>  todos los derechos reservados | Diseño y Desarrollo |
        
            <span class="lead"> <i class="fa fa-check"></i>&nbsp;&nbsp;Sorteo {{ config('app.name', 'Laravel') }}</span>
        </p>
    </div>
    <div class="clearfix"></div>
</footer>

