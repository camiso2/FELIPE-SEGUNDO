<!DOCTYPE html>
<html lang="en">

<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="google" value="notranslate">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

     

        <!-- Bootstrap core CSS -->

        <link href="/panel/css/bootstrap.min.css" rel="stylesheet">

        <link href="/panel/fonts/css/font-awesome.min.css" rel="stylesheet">
        <link href="/panel/css/animate.min.css" rel="stylesheet">

        <!-- Custom styling plus plugins -->
        <link href="/panel/css/custom.css" rel="stylesheet">

        <link href="/panel/css/icheck/flat/green.css" rel="stylesheet" />
        <link href="/panel/css/floatexamples.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="/panel/js/jquery.min.js"></script>
        <script src="/panel/js/nprogress.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
        <script>
            NProgress.start();
        </script>

    <!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
    <![endif]-->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->

      



  </head>


  <body class="nav-md">

    <?php if(session('alert_error')): ?>
    <script>
      $(document).ready(function()
      {
        $("#profile").modal("show");
    });
</script>
<?php echo $__env->make('sections.modal_profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>




<?php echo $__env->make('sections.menu_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- page content -->
<div class="right_col" role="main">

    <?php echo $__env->make('sections.preload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- top tiles -->
    <div class="row tile_count">
        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Participantes</span>
                <div class="count green"><?php echo e(count($participants)); ?></div>
                <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>100% </i> Participantes</span>
            </div>
        </div>


        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Participantes eliminados</span>
                <div class="count" style="color: red;"><?php echo e(count($pDeleted)); ?></div>
                <span class="count_bottom"><i class="red"><?php echo e(number_format((count($pDeleted)*100)/count($participants),2,',','.')); ?> %</i> Eliminados </span>
            </div>
        </div>
        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-clock-o"></i> Participantes en Sorteo</span>
                <div class="count"><?php echo e(count($participants)-count($pDeleted)); ?></div>
                <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i><?php echo e(number_format(100-(count($pDeleted)*100)/count($participants),2,',','.')); ?> % </i> Siguen </span>
            </div>
        </div>



    </div>
    <!-- /top tiles -->

    <div class="row">



       <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><b>DATOS DE LOS PARTICIPANTES</b><small>(Total : <?php echo e(count($participants)); ?> participantes)</small></h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>

                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div style="overflow-x:auto;">
                <?php if(count($participants)<1): ?>
                <h4>NO HAY PARTICIOPANTES EN EL SORTEO !</h4>
                <?php else: ?>
                <div class="x_content">
                    <?php if(session('participant')): ?>
                    <div class="alert alert-danger">
                        <i class="fa fa-trash fa-2x" aria-hidden="true" style="color: white !important;"></i>&nbsp;&nbsp;<?php echo e(session('participant')); ?>

                    </div>
                    <?php endif; ?>

                    <p>Los Participantes <code>Cumplen</code> con todos los requisitos para el sorteo !</p>
                    <script src="/panel/js/buscador.js"></script>
                    <div class="title_right" style="padding-top: 5px;">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                           <form  align ="left" id="form__" name="buscador" method="post" action="<?php echo e($_SERVER['PHP_SELF']); ?>" onKeypress="if(event.keyCode == 13) event.returnValue = false;" > 
                              <div class="input-group">
                                <input type="text" class="form-control"  value=""  id="buscar_employee" name="buscar" placeholder=" &#xf044; Buscar Participante" onkeyup="buscarItem(this.id)" style="font-family:Arial, FontAwesome">
                                <span class="input-group-btn">
                                  <button class="btn btn-default" type="button">Go!</button>
                              </span>
                          </div>

                      </form>
                  </div>


                  <table id="buscar_employees" class="table table-striped responsive-utilities jambo_table bulk_action" >
                    <thead>
                        <tr class="headings">
                            <th style="width: 5%;text-align: center;">
                                <i class="fa fa-registered" aria-hidden="true" ></i>&nbsp;&nbsp;
                            </th>
                            <th class="column-title" style="width: 5%;">Nacimiento </th>
                            <th class="column-title" style="width: 15%;">Nombres </th>
                            <th class="column-title" style="width: 15%;">Apellidos </th>
                            <th class="column-title" style="width: 25%;">Supermercado </th>
                            <th class="column-title" style="width: 10%;">Recibo </th>
                            <th class="column-title" style="width: 10%;">Inscripción </th>

                            <th class="column-title " style="width: 5%;font-size: 18px;"><span class="nobr"><i class="fa fa-trash"></i></span>
                            </th>

                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->state == null): ?>
                        <tr class="even pointer" >
                            <td class="a-center "><a href="data_users/<?php echo e($p->fper); ?>"><img src="data_users/<?php echo e($p->fper); ?>" class="img-resposive" width="40px;" id="silverfox" ></a>
                            </td>
                            <td class="cv" ><?php echo e($p->nacimiento); ?></td>
                            <td class=" cv"><?php echo e($p->nombres); ?> </td>
                            <td class=" cv"><?php echo e($p->apellidos); ?> </td>
                            <td class=" cv"><?php echo e($p->supermercado); ?></td>
                            <td class="cv"><?php echo e($p->recibo); ?></td>
                            <td class="cv "><?php echo e($p->created_at); ?></td>
                            <td class="cv">

                               <form class="form-horizontal" method="POST" action="<?php echo e(route('deleted_participants')); ?>"  onsubmit="return preload()" autocomplete="off">
                                <?php echo e(csrf_field()); ?>


                                <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                                <input type="hidden" name="nombres" value="<?php echo e($p->nombres); ?>">
                                <button type="submit" class="btn btn-danger btn-xs" onclick="
                                return confirm('Esta SEGURO que desea borrar el participante de su lista?')" 
                                ><i class="fa fa-trash"></i></button>

                            </form>
                        </td>
                    </tr>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>
<?php echo $__env->make('sections.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>


<div class="clearfix"></div>

<br />




<div id="custom_notifications" class="custom-notifications dsp_none">
    <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
    </ul>
    <div class="clearfix"></div>
    <div id="notif-group" class="tabbed_notifications"></div>
</div>

<script src="/panel/js/bootstrap.min.js"></script>

<!-- gauge js -->
<script type="text/javascript" src="/panel/js/gauge/gauge.min.js"></script>
<script type="text/javascript" src="/panel/js/gauge/gauge_demo.js"></script>

<!-- bootstrap progress js -->
<script src="/panel/js/progressbar/bootstrap-progressbar.min.js"></script>
<script src="/panel/js/nicescroll/jquery.nicescroll.min.js"></script>
<!-- icheck -->
<script src="/panel/js/icheck/icheck.min.js"></script>
<!-- daterangepicker -->
<script type="text/javascript" src="/panel/js/moment.min.js"></script>
<script type="text/javascript" src="/panel/js/datepicker/daterangepicker.js"></script>

<script src="/panel/js/custom.js"></script>




<script>
    NProgress.done();
</script>
<!-- /datepicker -->
<!-- /footer content -->
</body>

</html>


