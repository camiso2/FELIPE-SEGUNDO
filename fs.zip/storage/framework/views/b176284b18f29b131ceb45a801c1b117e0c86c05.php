<span id="loadPageM" >
    <img src="/images/preloads/preloader_5.gif" >

  <!--  <p >Cargando...</p>-->
</span>

<script type="text/javascript">
    function preload(){
        document.getElementById("loadPageM").style.display="block";
        return true;
    }
</script>