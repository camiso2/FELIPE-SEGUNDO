<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Participants extends Model
{
    protected $fillable = [
		'nacimiento',
        'nombres',
        'apellidos',
        'supermercado',
        'recibo',
        'fper',
	];
	/**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        '_token',
    ];
}
